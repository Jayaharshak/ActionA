  var a = angular.module("MyApp");
  a.controller("crudctrl", ['$scope','$state',function($scope,$state){
    $scope.reload = function(){
      $scope.detailsList = JSON.parse(localStorage.getItem('detailsList'));
    }
    $scope.reload();

    $scope.Remove = function (details) {
      //Find the record using Index from Array.

      var index = $scope.detailsList.indexOf(details);
      var name = $scope.detailsList[index].fname;
      if (window.confirm("Do you want to delete:row "+name)) {
        $scope.detailsList.splice(index, 1);
        localStorage.setItem('detailsList',JSON.stringify($scope.detailsList));

      }

    };
    $scope.Editrow = function(details){
      // var selected={}
      // selected = angular.copy($scope.details);
      $state.go('root.home.company.details.edit');
      $scope.index = $scope.detailsList.indexOf(details);
      $scope.firstfname= $scope.detailsList[$scope.index].fname;
      $scope.firstlname= $scope.detailsList[$scope.index].lname;
      $scope.firstemail= $scope.detailsList[$scope.index].email;

      $scope.updatedfname = $scope.detailsList[$scope.index].fname;
      $scope.updatedlname = $scope.detailsList[$scope.index].lname;
      $scope.updatedemail = $scope.detailsList[$scope.index].email;

  }
  $scope.onReset = function(){
    $scope.updatedfname = $scope.firstfname;
    $scope.updatedlname = $scope.firstlname;
    $scope.updatedemail = $scope.firstemail;
    // $scope.updatedfname = selected.fname;
    // $scope.updatedlname = selected.lname;
    // $scope.updatedemail = selected.email;
  }

    $scope.cancel=function(){
      $state.go('root.home.company.details');
    };
    $scope.update = function(){

      var updatedrow = {};
      updatedrow.fname = $scope.updatedfname;
      updatedrow.lname = $scope.updatedlname;
      updatedrow.email = $scope.updatedemail;
      // var index = $scope.personalDetails.indexOf(details);

      $scope.personalDetails.splice($scope.index, 1, updatedrow);
      $state.go('root.home.company.details');

    }
    $scope.reset = function(){
      $scope.updatedfname =$scope.selected;
      $scope.updatedlname= $scope.selected;
      $scope.updatedemail=$scope.selected;

    }


  }]);
