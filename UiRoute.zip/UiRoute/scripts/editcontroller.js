  var edit = angular.module('MyApp');
  edit.controller('editcontroller',['$scope','$state',function($scope,$state){
    $scope.cancel=function(){
      $state.go('root.home.company.details');
    };
    $scope.Editrow = function(details){
      $scope.selected = angular.copy(details);
    }
  }]);
