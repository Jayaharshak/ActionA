var app = angular.module('MyApp');
app.controller('jsonController',['$scope','$http',function($scope,$http){

  $scope.personalDetails=
  [{ "fname":"Muhammed",
  "lname":"Shanid",
  "email":"shanid@shanid.com"
},
{
  "fname":"John",
  "lname":"Abraham",
  "email":"john@john.com"
},
{
  "fname":"Roy",
  "lname":"Mathew",
  "email":"roy@roy.com"
}];
if (localStorage.getItem('detailsList') == null) {
  localStorage.setItem('detailsList',JSON.stringify($scope.personalDetails));
}
//  localStorage.setItem('personalDetails',JSON.stringify($scope.personalDetails));
}]);
