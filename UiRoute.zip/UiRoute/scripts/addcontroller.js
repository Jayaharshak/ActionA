  var add = angular.module('MyApp');
  add.controller('Addcontroller',['$scope','$state',function($scope,$state){
    $scope.Addnew = function () {
      //Add the new item to the Array.
      $scope.AddContinue();
      $state.go('root.home.company.details');
    };

    $scope.AddContinue = function () {
      //Add the new item to the Array.

      var row = {};
      row.fname = $scope.newfname;
      row.lname = $scope.newlname;
      row.email = $scope.newemail;
      $scope.detailsList.push(row);
      localStorage.setItem('detailsList',JSON.stringify($scope.detailsList));
      $scope.reload();
      $scope.newfname="";
      $scope.newlname="";
      $scope.newemail="";

    };

  }]);
