angular.module('MyApp',["ui.router"])
.config(function($stateProvider,$urlRouterProvider){

  $urlRouterProvider.otherwise("/home");
  $stateProvider
  .state('root', {
    abstract: true,
    url:''
  })
  .state('root.home', {
    url: '/home',
    templateUrl: '/views/home.html',

  }).state('root.home.company', {
    url: '/company',
    templateUrl: '/views/companiespanel.html',

  }).state('root.home.company.details', {
    url: '/details',
    templateUrl: '/views/companydetails.html',

  }).state('root.home.company.details.edit', {
    url: '/edit',
    templateUrl: '/views/companyEdit.html',

  }).state('root.home.company.details.addrow', {
    url: '/addrow',
    templateUrl: '/views/companyAdd.html',

  }).state('root.home.employees', {
    url: '/employees',
    templateUrl: '/views/employees.html'

  })


});
