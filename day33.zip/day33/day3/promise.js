var app=angular.module('app',[]);
app.controller('sampleCtrl', function($scope, $q)
{
	$scope.fail=false;
	$scope.test=function()
	{
		var deferred=$q.defer();
		var promise=deferred.promise;
		promise.then(function(result)
		{
			alert('success:'+result);
		},function(reason)
		{
			alert('error:'+reason);
	    });
		if($scope.fail)
			deferred.reject('sorry');
		else
			deferred.resolve('cool');
	};
});
	
