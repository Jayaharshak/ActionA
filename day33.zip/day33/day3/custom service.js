var app = angular.module('app', []);

app.service('MathService', function() {
    this.compare = function(a, b) { 
		var c;
		if (a>b){
			c=a;
		} else {		
			c=b;	
		}
	};
   
});

app.service('CalculatorService', function(MathService){
    
    this.compare1= function(a,b) {
		return MathService.compare(a,b);
	};
   

});

app.controller('CalculatorController', function($scope, CalculatorService) {

    $scope.doCompare = function() {
        $scope.answer = CalculatorService.compare1($scope.num1,$scope.num2);
    }

});