var app = angular.module('myApp', ['ngRoute']);

app.config(function($routeProvider) {
  $routeProvider

  .when('/', {
    templateUrl : 'pages/link1.html',
    controller  : 'LinkController'
  })

  .when('/link', {
    templateUrl : 'pages/link2.html',
    controller  : 'LinkkController'
  })
.otherwise({redirectTo: '/'});
});

app.controller('LinkController', function($scope) {
  $scope.message = 'this is the contents link 1';
});

app.controller('LinkkController', function($scope) {
  $scope.message = 'this is the contents link 2';
});


