var express = require('express');
var fs = require('fs');
var request = require('request');
var cheerio = require('cheerio');
var app     = express();

app.get('/',(req,res)=>{
  res.send('Welcome to crawling project..start crawling at /scrape route..!!')
})

app.get('/crawl',(req,res)=>{
  var pageToVisit = "http://www.arstechnica.com";
  console.log("Visiting page " + pageToVisit);
  request(pageToVisit, function(error, response, body) {
     if(error) {
       console.log("Error: " + error);
     }
     // Check status code (200 is HTTP OK)
     console.log("Status code: " + response.statusCode);
     if(response.statusCode === 200) {
       // Parse the document body
       var $ = cheerio.load(body);

       var keywords = $('a').text().split("a")







       console.log("Here comes array elements"+keywords[46]+"  Next word: "+keywords[24]+" And 5th word : "+keywords[22]);
       console.log("Length of array"+keywords.length)
       res.send("Page :  "+$('a').text());
       fs.writeFile('output.json', keywords, function(err){

      console.log('File successfully written! - Check your project directory for the output.json file');

  });
     }
  });
})

fs.writeFile('output.json', "Here is the string", function(err){

console.log('*****************output.json file');

})
app.listen(8082);
