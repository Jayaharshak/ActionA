import { Injectable } from '@angular/core';

import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { ThirdComponent } from './third/third.component';
import { TabItem } from './tab-items';

@Injectable()
export class TabsService {

  constructor() { }
  getTabs() {
    return [
      new TabItem(FirstComponent, {name: 'firstComponent'}),

      new TabItem(SecondComponent, {name: 'second one is here'}),

      new TabItem(ThirdComponent,  {name: 'Here comes third component'})

    ];
  }
}
