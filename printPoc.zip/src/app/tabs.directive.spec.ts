import { TabsDirective } from './tabs.directive';

describe('TabsDirective', () => {
  it('should create an instance', () => {
    const directive = new TabsDirective();
    expect(directive).toBeTruthy();
  });
});
