import { Component, OnInit } from '@angular/core';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material';

import { DialogDataExampleDialogComponent } from '../dialog-data-example-dialog/dialog-data-example-dialog.component';

@Component({
  selector: 'app-base',
  templateUrl: './base.component.html',
  styleUrls: ['./base.component.css']
})
export class BaseComponent implements OnInit {
public tabslist = [ {'tag': '<app-first></app-first>'},
                    {'tag': '<app-second></app-second>'},
                    {'tag': '<app-third></app-third>'}
                  ];
  constructor(public dialog: MatDialog) {}
  ngOnInit() { }
  openDialog() {
        this.dialog.open(DialogDataExampleDialogComponent, {
          disableClose: false,
          width: '60%',
          height: '300px',
          position: {
            top: '60px',
            left: '20%'
          },
          data: {
            tabslist: this.tabslist
          }
        });
       }
}
