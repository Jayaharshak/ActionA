// Core modules
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// Angular Material modules
import {  MatTabsModule,
          MatButtonModule,
          MatButtonToggleModule,
          MatDialogModule,
          MatCheckboxModule,
          MAT_DIALOG_DEFAULT_OPTIONS } from '@angular/material';
// App Components
import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component';
import { SecondComponent } from './second/second.component';
import { ThirdComponent } from './third/third.component';
import { BaseComponent } from './base/base.component';
import { DialogDataExampleDialogComponent } from './dialog-data-example-dialog/dialog-data-example-dialog.component';
import { FinalDialogComponent } from './final-dialog/final-dialog.component';
import { CommonService } from './common.service';
import { TabsDirective } from './tabs.directive';
import { TabsService } from './tabs.service';


@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    SecondComponent,
    ThirdComponent,
    BaseComponent,
    DialogDataExampleDialogComponent,
    FinalDialogComponent,
    TabsDirective
  ],
  imports: [
              BrowserModule,
              BrowserAnimationsModule,
              MatTabsModule,
              FormsModule,
              MatButtonModule,
              MatButtonToggleModule,
              MatDialogModule,
              MatCheckboxModule
            ],
  providers: [CommonService,
              TabsService,
            ],
  bootstrap: [AppComponent],
  entryComponents: [
    DialogDataExampleDialogComponent,
    FinalDialogComponent,
    FirstComponent,
    SecondComponent,
    ThirdComponent
]
})
export class AppModule { }
