import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import {  Injectable,
          Injector,
          ComponentFactoryResolver,
          EmbeddedViewRef,
          ApplicationRef,
          ComponentRef } from '@angular/core';
import {MatDialog, MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
// import { CommonService } from '../common.service';
import { FirstComponent } from '../first/first.component';
import { SecondComponent } from '../second/second.component';
import { ThirdComponent } from '../third/third.component';
import { TabsDirective } from '../tabs.directive';
import { TabsService } from '../tabs.service';
import { TabItem } from '../tab-items';

@Component({
  selector: 'app-final-dialog',
  templateUrl: './final-dialog.component.html',
  styleUrls: ['./final-dialog.component.css']
})
export class FinalDialogComponent implements OnInit {
  @ViewChild(TabsDirective) tabHost: TabsDirective;
  tabs: TabItem[];
  WinPrint: Window;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
  private dialogRef: MatDialogRef<FinalDialogComponent>,
  // private commonService: CommonService,
  private componentFactoryResolver: ComponentFactoryResolver,
  private appRef: ApplicationRef,
  private injector: Injector,
  private tabsService: TabsService) { }
  // Function to print given DOM
  print() {
    const prtContent = document.getElementById('finalId');
    // const prtContent = document.getElementById('pringId');
    const viewContainerRef = this.tabHost.viewContainerRef;
    this.WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
    this.WinPrint.document.write(prtContent.innerHTML);
    // this.WinPrint.document.write(viewContainerRef.innerHTML);
    this.WinPrint.document.close();
    this.WinPrint.focus();
    this.WinPrint.print();
    this.WinPrint.close();
    }
  ngOnInit() {
    this.tabs = this.tabsService.getTabs();
    console.log(this.tabs);
    this.loadComponent();
   }
  // Here tabs appending is done.
  tabsDialog = function() {
    document.getElementById('refDiv').innerHTML = this.data.finalTabs[0].tag.trim();
    document.createElement('app-second');
  };
  closeDialog() {
    this.dialogRef.close();
  }
  appendComponentToBody = function(component: any) {
    // Create a component reference from the component
    const componentRef = this.componentFactoryResolver
      .resolveComponentFactory(component)
      .create(this.injector);
    // Attach component to the appRef so that it's inside the ng component tree
    this.appRef.attachView(componentRef.hostView);
    // Get DOM element from component
    const domElem = (componentRef.hostView as EmbeddedViewRef<any>)
      .rootNodes[0] as HTMLElement;
    // Append DOM element to the body
    document.getElementById('finalId').appendChild(domElem);
   };
  loadComponent() {
    const viewContainerRef = this.tabHost.viewContainerRef;
    viewContainerRef.clear();
    for (let i = 0; i < this.tabs.length; i++) {
      const tabItem = this.tabs[i];
      const componentFactory = this.componentFactoryResolver.resolveComponentFactory(tabItem.component);
      const componentRef = viewContainerRef.createComponent(componentFactory);
      (componentRef.instance).data = tabItem.data;
      this.appendComponentToBody(tabItem.component);
    }
  }
}
