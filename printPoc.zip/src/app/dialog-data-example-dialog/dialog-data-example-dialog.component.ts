import { Component, OnInit, Inject } from '@angular/core';
import {MatDialog, MAT_DIALOG_DATA, MatDialogRef} from '@angular/material';
import { FinalDialogComponent } from '../final-dialog/final-dialog.component';

@Component({
  selector: 'app-dialog-data-example-dialog',
  templateUrl: './dialog-data-example-dialog.component.html',
  styleUrls: ['./dialog-data-example-dialog.component.css']
})
export class DialogDataExampleDialogComponent implements OnInit {
  public tabstoPrint = this.data.tabslist;
  public tabsArray: Array<String>;
  public theCheckbox = true;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
                 private dialogRef: MatDialogRef<DialogDataExampleDialogComponent>,
                 public dialog: MatDialog) {}

  ngOnInit() {
    this.tabsArray = this.data.tabslist;
  }
  // Closing the dialog box.
  closeDialog() {
    this.dialogRef.close();
    console.log(this.data.tabslist);
  }
  // Opening tabs dialog box(New dialog box).
  tabsDialog(tabstoPrint) {
    this.closeDialog();
    this.dialog.open(FinalDialogComponent, {
      disableClose: true,
      width: '60%',
      height: '500px',
      position: {
        top: '60px',
        left: '20%'
      },
      id: 'finalId',
      data: {
        finalTabs: this.tabsArray
      }
    });
  }
  // For checkbox change detection.
  changeEvent(event) {
    console.log(event.checked);
    console.log(JSON.stringify(event.target));
    console.log(this.theCheckbox);
  }
  allComplete($event) {
    console.log('This is allComplete event');
  }

}
