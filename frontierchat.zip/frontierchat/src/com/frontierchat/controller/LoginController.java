package com.frontierchat.controller;

import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.security.NoSuchAlgorithmException;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import com.frontierchat.loginmodel.UserModel;
import com.frontierchat.loginservice.UserService;
import com.frontierchat.loginservice.UserServiceImpl;

@Path("/control")
public class LoginController {
	@Path("/newUser")
	@POST
	public Response addingNewUser(
			@FormParam("name") String name,
			@FormParam("email") String email,
			@FormParam("pwd") String pwd
			) throws UnknownHostException, UnsupportedEncodingException, NoSuchAlgorithmException, URISyntaxException{
		UserService userService = new UserServiceImpl();
		UserModel userModel = new UserModel();
		userModel.setName(name);
		userModel.setEmail(email);
		userModel.setPassword(pwd);
		return userService.addNewUser(userModel);
	}
	@POST
	@Path("/userLogin")
	public Response userLogin(
			@FormParam("email") String email,
			@FormParam("pwd") String password
			) throws UnknownHostException, NoSuchAlgorithmException, UnsupportedEncodingException, URISyntaxException{
		UserModel user = new UserModel();
		UserService userService = new UserServiceImpl();
		user.setEmail(email);
		user.setPassword(password);
		
		return userService.userLoginCheck(user);
	}
	
	@Path("/getUserDetails")
	@GET
	public Response getUserDetails() {
		
		UserModel user = new UserModel();
		UserService userService = new UserServiceImpl();
		
		return data;
		
	} 
	
}

