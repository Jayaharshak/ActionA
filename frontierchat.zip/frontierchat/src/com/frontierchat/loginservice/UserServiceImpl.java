package com.frontierchat.loginservice;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.ws.rs.core.Response;

import com.frontierchat.dao.UserDetailsDao;
import com.frontierchat.dao.UserDetailsDaoImpl;
import com.frontierchat.loginmodel.UserModel;
import com.frontierchat.loginservice.UserService;


public class UserServiceImpl implements UserService {
	UserDetailsDao userDetails = new UserDetailsDaoImpl();
	@Override
	public Response addNewUser(UserModel user) throws UnknownHostException,
	UnsupportedEncodingException, NoSuchAlgorithmException, URISyntaxException{
		URI location;
		if(userDetails.insertDataForSignUp(user)){
			location = new URI("https://www.facebook.com");	
		}
		else{
			location = new URI("https://www.facebook.com");
		}
		return Response.temporaryRedirect(location).build();
	}
	
	
	@Override
	public String Md5Encrypt(String data) throws NoSuchAlgorithmException, UnsupportedEncodingException{
		String encryptPassword = new String();
		byte[] passwordInByte = data.getBytes("UTF-8");
		MessageDigest messageDigest = MessageDigest.getInstance("MD5");
		byte[] digestPassword = messageDigest.digest(passwordInByte);
		for (int i = 0; i < digestPassword.length; i++)
	        encryptPassword += Integer.toString((digestPassword[i] & 0xff) + 0x100, 16).substring(1);
		return encryptPassword;
	}
	@Override
	public Response userLoginCheck(UserModel user) throws UnknownHostException,
	NoSuchAlgorithmException, UnsupportedEncodingException, URISyntaxException{
		UserModel gotUser = new UserModel();
		URI location;
		gotUser = userDetails.fetchRowByEmail(user);
		String checkPassword = Md5Encrypt(user.getPassword());
		if(checkPassword.equals(gotUser.getPassword())){
			location = new URI("https://www.facebook.com");
		}
		else{
			location = new URI("https://www.facebook.com");
		}
		return Response.temporaryRedirect(location).build();
		
	}
}

