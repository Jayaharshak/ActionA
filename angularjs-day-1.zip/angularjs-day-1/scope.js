
		var a=angular.module("myapp",[])
		a.controller("ParentCtrl",function($scope){
		$scope.companyname="ofs";
		$scope.employeename="Jayaharsha";
		

		});
		a.controller("ChildCtrl",function($scope){
		$scope.age="22";

		});


	
