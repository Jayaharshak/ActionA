$(document).ready(function (){
	
//1. Disable the refresh option in html page using jQuery

	$(document).keydown(function(e){
		key= e.which;
		 $(".divide").html(e.which);
			if(key==116){
				e.preventDefault();
							$(".divide").html("F5 is Disabled!");
				}
		});
	
//2. Disable/enable the form submit button.Disable the submit button until the visitor has clicked a check box.
	
	$("form").submit( function(e) {
		e.preventDefault();
	
	}); 
	$(":checkbox").click(function(){
		if(this.checked){
				$("#sub").prop('disabled',false);
			}
				else{
					$("#sub").prop('disabled',true);
					}
		
	});	

 //3. Using jQuery on clicking on the button remove all the options of a select box and then add one option and select it

    $("#click").click(function (){
       $('#myColor')
         .empty()
         .append('<option selected="selected" value="test">White</option>');
    });
    $("#add").click(function(){
		$("#select").append('<option value="option1">New Option</option>');
		
	}); 

//4. Remove all CSS classes in any of the element using jQuery.
		
	$(document).ready(function(){
      $("button").click(function(){
        $("p").removeClass("sample");
        });
    });	

//5. How to detect a textbox's content has changed using jQuery? print the changed values in console.
	
    $("#textBox").change(function(){
		alert("Text Box is altered , refer Console to see the changed text");
		console.log("The Changed Value in Text Box is   "+this.value+"   on    "+Date());
		
		
	});	

//6. Count child elements using jQuery.
	$("#press").click(function(){
		var count=$("#selected  li,p").length;
		alert(count);
	});
	
//7.Remove the specific table row using JQuery
    $("#button").click(function(){
     $("#r2").remove();
	});	 

	});









