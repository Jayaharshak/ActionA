alert("hello world");
function demo()
{
var c,d,b=20;
c= eval(a+b);
d= isNaN(c);
alert("sum: "+c+"     not a number : "+d);
}

