function callBack(c,e)
{
	this.c=c;
	e(this.c);
}
function displayName(x) {
    
    document.write ("<h1>Hello "  + x+" !</h1>");
	alert("Hello "+ x+" !");
}

function evaluateThis() {

   var a = eval(" 3*2 ")+ "<br>";
    var b = eval("2 + 7") + "<br>";
    var c = eval("6/2") + "<br>";
	 var d = eval("5-10") + "<br>";
	 document.writeln("3*2: ",a);
	  document.writeln("2+7: ",b);
	   document.writeln("6/2: ",c);
	    document.writeln("5-10: ",d);

   //var res=a+b+c+d;
    //document.getElementById("demo").innerHTML =res;
}
function avgMark(){


var print = {
             name1:"bala",
			 mark1:75,
             name2:"rajesh",
			 mark2:53,
             name3:"solomon",
			 mark3:80, 
             name4:"shoshan",
			 mark4:62,
			 printfunc:function(){
			 return this.name1+""+this.mark1;
			  return this.name2+""+this.mark2;
			   return this.name3+""+this.mark3;
			    return this.name4+""+this.mark4;
			 }
			};
var marks=[75,80,53,62];
var sum=eval("marks[0]+marks[1]+marks[2]+marks[3]");
var avg= eval("sum/4");
var dis="";
var i;
for (i = 0; i < marks.length; i++) {
    dis += marks[i] + "<br>";
}
document.writeln( "marks<br>"+ dis+"");
 document.writeln("average mark is"+avg+"<br>");
 
}
function browserInfo(){
document.write("your browser info:"+navigator.appVersion+"<br>");
document.write("your browser height:"+screen.height+"<br>");

document.write("your browser width:"+screen.width+"<br>");
}
