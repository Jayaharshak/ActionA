 x={
    "Students": {
        "AnnualExamResults": [
            {
                "id": "1",
                "firstName": "Tom",
                "lastName": "Cruise",
                "subjects": [
                      { "name": "physics", "mark": 70 },
                      { "name": "chemistry", "mark": 60 },
                      { "name": "maths", "mark": 15 },
                      { "name": "ComputerScience", "mark": 80 }
                ]
            },
            {
                "id": "2",
                "firstName": "Maria",
                "lastName": "Sharapova",
                "subjects": [
                  { "name": "physics", "mark": 72 },
                  { "name": "chemistry", "mark": 50 },
                  { "name": "maths", "mark": 90 },
                  { "name": "ComputerScience", "mark": 50 }
              ]
            },
            {
                "id": "3",
                "firstName": "James",
                "lastName": "Bond",
                "subjects": [
                  { "name": "physics", "mark": 60 },
                  { "name": "chemistry", "mark": 30 },
                  { "name": "maths", "mark": 70 },
                  { "name": "ComputerScience", "mark": 50 }
              ]
            },
            {
                "id": "4",
                "firstName": "Ryan",
                "lastName": "Dhal",
                "subjects": [
                  { "name": "physics", "mark": 62 },
                  { "name": "chemistry", "mark": 90 },
                  { "name": "maths", "mark": 35 },
                  { "name": "ComputerScience", "mark": 85 }
              ]
            },
            {
                "id": "5",
                "firstName": "Mark",
                "lastName": "Zuckerberg",
                "subjects": [
                  { "name": "physics", "mark": 35 },
                  { "name": "chemistry", "mark": 70 },
                  { "name": "maths", "mark": 35 },
                  { "name": "ComputerScience", "mark": 90 }
              ]
            },
            {
                "id": "6",
                "firstName": "Priscilla",
                "lastName": "Chan",
                "subjects": [
                  { "name": "physics", "mark": 90 },
                  { "name": "chemistry", "mark": 95 },
                  { "name": "maths", "mark": 100 },
                  { "name": "ComputerScience", "mark": 90 }
              ]
            },
            {
                "id": "7",
                "firstName": "Balaji",
                "lastName": "Viswanathan",
                "subjects": [
                  { "name": "physics", "mark": 90 },
                  { "name": "chemistry", "mark": 95 },
                  { "name": "maths", "mark": 50 },
                  { "name": "ComputerScience", "mark": 90 }
              ]
            },
            {
                "id": "8",
                "firstName": "Glen",
                "lastName": "Murphy",
                "subjects": [
                  { "name": "physics", "mark": 70 },
                  { "name": "chemistry", "mark": 75 },
                  { "name": "maths", "mark": 80 },
                  { "name": "ComputerScience", "mark": 50 }
              ]
            },
            {
                "id": "9",
                "firstName": "Jimmy",
                "lastName": "wales",
                "subjects": [
                  { "name": "physics", "mark": 60 },
                  { "name": "chemistry", "mark": 100 },
                  { "name": "maths", "mark": 70 },
                  { "name": "ComputerScience", "mark": 65 }
              ]
            },
            {
                "id": "10",
                "firstName": "Sheryl",
                "lastName": "Sandberg",
                "subjects": [
                  { "name": "physics", "mark": 80 },
                  { "name": "chemistry", "mark": 35 },
                  { "name": "maths", "mark": 45 },
                  { "name": "ComputerScience", "mark": 75 }
              ]
            }
        ]
    }
}




id=[];
firstName=[];
lastName=[];
physics=[];
chemistry=[];
maths=[];
ComputerScience=[]; 
total=[];
total1=[];
avg=[];
rank=[];
ranking=[];


function createTable(){
	
	collection=[id,firstName,lastName,physics,chemistry,maths,ComputerScience,total,avg,ranking]

	for(var i=0;i<Object.keys(x.Students.AnnualExamResults).length;i++)
			
			{
				id[i]=x.Students.AnnualExamResults[i].id;
				firstName[i]=x.Students.AnnualExamResults[i].firstName;
				lastName[i]=x.Students.AnnualExamResults[i].lastName;
				physics[i]=x.Students.AnnualExamResults[i].subjects[0].mark;
				chemistry[i]=x.Students.AnnualExamResults[i].subjects[1].mark;
				maths[i]=x.Students.AnnualExamResults[i].subjects[2].mark;
				ComputerScience[i]=x.Students.AnnualExamResults[i].subjects[3].mark
				
			}
			
		colLength=document.getElementById("table").rows[0].cells.length;
		
		for(var i=0;i<colLength;i++)
		{
			
			total[i]=physics[i]+chemistry[i]+maths[i]+ComputerScience[i];
			avg[i]=total[i]/(x.Students.AnnualExamResults[0].subjects).length	
			total1[i]=total[i];
		}
		
	total1.sort(function(a,b){return b-a});
	for(var i=0;i<colLength;i++){
	for(var k=0;k<colLength;k++){
		if(total[i]==total1[k])
		{
			ranking[i]=k+1;
		}
	}	
	}
	
		for(var i=0;i<colLength;i++)
			
			{
							
			var row=document.getElementById("table").insertRow();
				for(k=0;k<Object.keys(x.Students.AnnualExamResults).length;k++){
					
					row.insertCell(k).innerHTML=collection[k][i];
						
					
				}
					
			
				
			}

}





