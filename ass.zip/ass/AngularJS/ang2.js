var app = angular.module('myApp', []);
		app.directive('myDirective',function(){
		return 
		{
			
		template: "<h3>Name:vini dept:cse email:vini@gmail.com</h3>"
		};
	});
	//$broadcast and $emit events
	app.controller('Parent', function($scope) 
	{
		$scope.message="";
		$scope.emitmessage="";
		$scope.clickevent=function()
		{
		$scope.$broadcast('transfer',{message:$scope.message});
		}
		$scope.$on('transferUp',function(event,data)
		{
		$scope.emitmessage=data.message;
		});
	});

	app.controller('Child',function($scope)
	{
		$scope.message="";
		$scope.broadcastmessage=""
		$scope.$on('transfer',function(event,data)
		{
		$scope.broadcastmessage=data.message;
		});
		$scope.clickevent=function()
		{
		$scope.$emit('transferUp',{message:$scope.message});
		}
	});
	//custom filter
	app.controller('custom', ['$scope', function($scope){
		$scope.monthNumber = '';
	}]);
	app.filter('monthName', [function() 
	{
		return function (monthNumber) 
		{ 
			var monthNames = [ 'January', 'February', 'March', 'April', 'May', 'June',
            'July', 'August', 'September', 'October', 'November', 'December' ];
			return monthNames[monthNumber - 1];
		}
	}]);

    //table view of book details
	app.controller("format",function($scope){
		$scope.tutorials=[
		{Title:"Title", Author:"Author", Price:"Price"},
		{Title:"Pride and Prejudice", Author:"Jane Austen", Price:"69"},
		{Title:"Moby-Dick", Author:"Herman Melville", Price:"85"},
		{Title:"Tom Jones", Author:"Henry Fielding", Price:"52"}
		]
	});
	// form validation
	app.controller('validateCtrl', function($scope) {
    $scope.user = "";
    $scope.email = "";
	$scope.id="";
	$scope.limitKeypress = function ($event, value, maxLength) {
        if (value != undefined && value.toString().length >= maxLength) {
            $event.preventDefault();
        }
    }

});