 var app = angular.module('myApp', []);
         //hello angular and sum of two digits
		 app.controller('myCtrl', function($scope) {	
			 $scope.first="Hello";
			 $scope.second="ANGULAR";
         });
         
		 //two way binding
		 app.controller('myCtrl1', function($scope) {
			$scope.updateModel=function()
			 {
			 return $scope.firstname;
			 }
			});
         
		 //one way binding
		 app.controller('myCtrl2', function($scope) {
			 $scope.name = "vini";
			 $scope.changeName = function() {
			 $scope.name = "sara";
			 }
				$scope.displayName=function()
				{
				return $scope.name1;
				}
			});
         
		 //one time binding
		 app.controller('myCtrl3', function($scope) {
			$scope.name1="vini";
			$scope.changeName1=function()
				{
				$scope.name1="sara";
				}
			});
		 
		 //parent child controller
		 app.controller('parent',function($scope) {
			 $scope.title1="parent controller";
			 
			});
		 app.controller('child',function($scope) {
			 $scope.title2="child controller";
			 
			});	
         