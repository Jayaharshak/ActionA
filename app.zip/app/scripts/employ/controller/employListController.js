angular.module('myapp.employee', [])
        .controller('employeeListController',["$scope","$state","employeeService", function(
            $scope,
            $state,
            employeeService) {
            var init = function init() {
              $scope.employeeInfo = {};
              employeeService.doGetEmployee(cbsEmployee);
            };

            function cbsEmployee(response) {
            $scope.employeeInfo.data = response;
        };

            $scope.onCreate = function onCreate() {
              flag = 2;
              $state.go('root.home.employee.list.details', {id: ''});
        };

            $scope.onEdit = function onEdit(employeeId) {
              flag = 1;
              $state.go('root.home.employee.list.details', {id: employeeId});
          };

            $scope.onDelete = function onDelete(employeeId) {
            $scope.employeeInfo.data = employeeService.deleteItemById(employeeId);
          };
        init();
}]);
