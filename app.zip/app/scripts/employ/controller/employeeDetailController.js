angular.module('myapp.employee')
    .controller('employeeDetailController',
        ["$scope",
         "$state",
         "employeeService", function (
          $scope,
          $state,
          employeeService) {

      var existingEmployeeDetails = {};
      var init = function init () {
          $scope.employeeMetaInfo = {};
          var employeeId = $state.params.id;
          if (employeeId) {
              $scope.employeeMetaInfo = employeeService.doGetEmployeeById(employeeId);
          }
          existingEmployeeDetails = angular.copy($scope.employeeMetaInfo);
        };

            $scope.onReset = function onReset() {
            $scope.employeeMetaInfo = angular.copy(existingEmployeeDetails);
        };

        $scope.onCancel = function onCancel() {
          $state.go('root.home.employee.list');
        };

        $scope.onSave = function onSave () {
          data = $scope.employeeMetaInfo;
          data.id = existingEmployeeDetails.id;
          employeeService.saveData(data);
          location.reload();
          $state.go('root.home.employee.list');
        };
    init();
}]);
