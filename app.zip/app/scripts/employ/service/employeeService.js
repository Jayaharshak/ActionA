angular.module('myapp.employee')
    .service("employeeService",
        ["$http",
         "localStorageService",function(
          $http,
          localStorageService)  {

            this.doGetEmployee = function doGetEmployee(cbsEmployee){
              var items = this.getEmployeeFromCache();
              if(!items) {
                $http.get('data/employeeData.json').then(function(response){
                    localStorageService.create('employee', response.data);
                    cbsEmployee(response.data);
                })
             } else {
                cbsEmployee(items);
              }
          };
                this.doGetEmployeeById = function doGetEmployeeById (id) {
                return localStorageService.getItem('employee', id);
            };

            this.isDataAlreadyExists = function isDataAlreadyExists() {
                return true;
            };

            this.getEmployeeFromCache = function getEmployeeFromCache() {
              return localStorageService.getItems('employee');
            };

            this.deleteItemById = function deleteItemById(id) {
              localStorageService.deleteItem('employee', id);
              return localStorageService.getItems('employee');
            };


            this.saveData = function saveData(data){
              if((data.name != null) && (data.salary != null) && (data.salary != null))  {
               localStorageService.update('employee', data);
               localStorageService.getItems('employee');
             }
            };
}]);
