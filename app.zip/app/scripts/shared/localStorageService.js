angular.module('myapp.shared',[])
    .service('localStorageService',
         function () {

           this.create = function create(key, response) {
          localStorage.setItem(key, JSON.stringify(response));
          };

           this.getItems = function getItems(key) {
              var items = localStorage.getItem(key);
              return JSON.parse(items);
          };

          this.getItem = function getItem(key, id) {
            var items = localStorage.getItem(key);
            items = JSON.parse(items);
            var item = {};
            for (var i=0; i<items.length; i++) {
                if (id == items[i].id) {
                    item = items[i];
                }
            }
            return item;
        };

        this.update = function update(key,updatedItem) {
          var items = localStorage.getItem(key);
          items = JSON.parse(items);
          if(flag==1){
          for (var i=0; i<items.length; i++) {
              if (updatedItem.id == items[i].id) {
                  item = items[i];
                  items.splice(items.indexOf(item), 1,updatedItem );
              }
            }
            this.create(key, items);
          }
          if(flag==2) {
            var count=0;
            for (var i=0; i<items.length; i++) {
              idNo = items[i].id+1;
              }
              updatedItem.id = idNo;
            items.push(updatedItem);
            this.create(key, items);
          }
        };

        this.deleteItem = function deleteItem(key, id) {
          var items = localStorage.getItem(key);
          items = JSON.parse(items);
          var item = {};
          for (var i=0; i<items.length; i++) {
              if (id == items[i].id) {
                  item = items[i];
                  break;
              }
          }
          items.splice(items.indexOf(item) , 1);
          this.create(key, items);
          }
});
