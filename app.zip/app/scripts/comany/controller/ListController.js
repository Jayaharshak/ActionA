angular.module('myapp.Company',[])
        .controller('companyListController',["$scope","$state","companyservice", function(
            $scope,
            $state,
            companyservice) {
            var init = function init() {
              $scope.companyInfo = {};
              companyservice.doGetCompanies(cbsCompanies);
            };

            function cbsCompanies(response) {
            $scope.companyInfo.data = response;
        };

            $scope.onCreate = function onCreate() {
              flag = 2;
              $state.go('root.home.company.list.details', {id: ''});
        };

            $scope.onEdit = function onEdit(companyId) {
              flag = 1;
              $state.go('root.home.company.list.details', {id: companyId});
          };

            $scope.onDelete = function onDelete(companyId) {
            $scope.companyInfo.data = companyservice.deleteItemById(companyId);
          };
        init();
}]);
