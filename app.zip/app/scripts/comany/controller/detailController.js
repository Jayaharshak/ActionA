angular.module('myapp.Company')
    .controller('companyDetailsController',
        ["$scope",
         "$state",
         "companyservice", function (
          $scope,
          $state,
          companyservice) {

      var existingCompanyDetails = {};
      var init = function init () {
          $scope.companyMetaInfo = {};
          var companyId = $state.params.id;
          if (companyId) {
              $scope.companyMetaInfo = companyservice.doGetCompanyById(companyId);
          }
          existingCompanyDetails = angular.copy($scope.companyMetaInfo);
        };

            $scope.onReset = function onReset() {
            $scope.companyMetaInfo = angular.copy(existingCompanyDetails);
        };

        $scope.onCancel = function onCancel() {
          $state.go('root.home.company.list');
        };

        $scope.onSave = function onSave () {
          data = $scope.companyMetaInfo;
          data.id = existingCompanyDetails.id;
          companyservice.saveData(data);
          location.reload();
          $state.go('root.home.company.list');
        };
    init();
}]);
