angular.module('myapp.Company')
    .service("companyservice",
        ["$http",
         "localStorageService",function(
          $http,
          localStorageService)  {

            this.doGetCompanies = function doGetCompanies(cbsCompanies){
              var items = this.getCompaniesFromCache();
              if(!items) {
                $http.get('data/companyData.json').then(function(response){
                    localStorageService.create('companies', response.data);
                    cbsCompanies(response.data);
                })
             } else {
                cbsCompanies(items);
              }
          };
                this.doGetCompanyById = function doGetCompanyById (id) {
                return localStorageService.getItem('companies', id);
            };

            this.isDataAlreadyExists = function isDataAlreadyExists() {
                return true;
            };

            this.getCompaniesFromCache = function getCompaniesFromCache() {
              return localStorageService.getItems('companies');
            };

            this.deleteItemById = function deleteItemById(id) {
              localStorageService.deleteItem('companies', id);
              return localStorageService.getItems('companies');
            };


            this.saveData = function saveData(data){
              if((data.name != null) && (data.salary != null) && (data.salary > 0))  {
               localStorageService.update('companies', data);
               localStorageService.getItems('companies');
             }
            };
}]);
