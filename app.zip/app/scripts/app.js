angular.module('myapp', ["ui.router","myapp.Company","myapp.employee","myapp.shared"])
    .config(function($stateProvider, $urlRouterProvider){

      $urlRouterProvider.otherwise("/home");

      $stateProvider
          .state('root', {
              abstract: true,
              url:''
          })
          .state('root.home', {
              url: '/home',
              templateUrl: 'views/home.html'

          }).state('root.home.company', {
              url: '/company',
              templateUrl: 'views/company/companyPanel.html'

          }).state('root.home.company.list', {
              url: '/list',
              controller: 'companyListController',
              templateUrl: 'views/company/companyList.html'

          }).state('root.home.company.list.details', {
              url: '/details/:id',
              controller: 'companyDetailsController',
              templateUrl: 'views/company/companyDetails.html'

          }).state('root.home.employee', {
              url: '/employee',
              templateUrl: 'views/employee/employeePanel.html'

          }).state('root.home.employee.list', {
              url: '/list',
              controller: 'employeeListController',
              templateUrl: 'views/employee/employeeList.html'

          }).state('root.home.employee.list.details', {
              url: '/details/:id',
              controller: 'employeeDetailController',
              templateUrl: 'views/employee/employeeDetails.html'

          });
    });
